# Virtual Camera (Android)

Play a video or an image from the device's storage **as if it were the live camera** —
for use with YouTube Live, TikTok, Instagram, Zoom, Meet, and anything else that wants
a camera or a screen share.

Kotlin · Gradle (Kotlin DSL) · Media3/ExoPlayer · Camera2-shaped virtual device ·
MediaProjection fallback · minSdk 24 · targetSdk 34

---

## Read this first: what Android actually allows

This is the single most important section, and it is why the app is built the way it is.

**A normal Android app cannot inject frames into another app's camera stream.** This is
not a missing feature — it is an architectural boundary:

- The real camera stack runs in `cameraserver`, a system daemon started by `init`.
- It loads camera drivers from HAL modules (`/vendor/lib(64)/hw/camera.<provider>.so`)
  that must be signed into the vendor/system partition and listed in the camera
  provider allow-list.
- `CameraManager` / `CameraService` only ever expose cameras that came from that HAL.
  There is **no public API** to register a new camera, and `CameraService` rejects
  callers whose UID is not the camera provider's.
- Apps that open the camera (`Camera2` / CameraX) get a `CameraDevice` bound to a real
  hardware session. You cannot substitute it from outside that process.

So the practical options, honestly ranked:

| # | Approach | Root needed | Works for | Status in this app |
|---|----------|-------------|-----------|--------------------|
| 1 | **Be the default camera app** (intent filters for `IMAGE_CAPTURE`, `STILL_IMAGE_CAMERA`, `VIDEO_CAMERA`, `VIDEO_CAPTURE`) | No | Any app that uses the camera **intent** API or the system camera shortcut | ✅ Implemented — main path |
| 2 | **MediaProjection screen source** | No | Any app that accepts a **screen share** instead of a camera | ✅ Implemented — fallback |
| 3 | **Virtual camera HAL** (`camera.virtual.so` built with the AOSP camera provider HAL interface, or a GSI/ROM build) | Yes / custom ROM | Every app, including ones that use Camera2 directly | 📄 Documented, not included (see below) |
| 4 | **LSPosed / Xposed hook** on `CameraManager.openCamera` / `CameraDeviceImpl` | Yes (root + LSPosed) | Every app on the device | 📄 Documented, not included (see below) |

Options 3 and 4 are genuinely out of scope for a distributable APK — they are not
"a bit more work", they are a different class of software (a vendor HAL shared library
signed into the system image, or a runtime hook framework). The interfaces they would
plug into are already in this codebase: see `VirtualCameraProvider`,
`VirtualCameraDevice` and `FrameBus`. Swapping the in-process device for a HAL bridge
that reads `FrameBus` over a local socket is the intended extension point, and the
README says so rather than pretending the APK can do it.

---

## What works out of the box

After `./gradlew installDebug` and picking a file:

- ✅ **Media picker** — system Photo Picker on Android 13+, Storage Access Framework
  `OpenDocument` otherwise. The read grant is **persisted**, so the app can still read
  the file after a reboot.
- ✅ **Looping playback engine** — ExoPlayer (Media3) decodes the video into an offscreen
  `SurfaceTexture`; every frame is transferred to a shared `Bitmap` and published to
  `FrameBus`. Images are decoded once and re-published on a 1 s tick. Looping is
  infinite, so the "camera" never goes black.
- ✅ **Live preview** — renders `FrameBus` through the same `SurfaceFrameWriter` the
  camera path uses, with an fps counter. Preview and output cannot drift apart because
  they are literally the same frames.
- ✅ **Foreground service** — `foregroundServiceType="camera|mediaProjection"` with a
  persistent notification and a Stop action. Playback keeps running when you switch to
  another app or lock the screen.
- ✅ **Camera2-shaped virtual device** — `VirtualCameraProvider` (camera id list,
  characteristics, open/close, `DeviceStateCallback`) and `VirtualCameraDevice`
  (`createCaptureSession`, `CaptureRequest`, `CaptureSessionCallback`) mirror the real
  API and push `FrameBus` frames into any `Surface` you give them, through EGL.
- ✅ **Default-camera-app path** — `CameraIntentActivity` answers `IMAGE_CAPTURE`,
  `IMAGE_CAPTURE_SECURE`, `STILL_IMAGE_CAMERA`, `STILL_IMAGE_CAMERA_SECURE`,
  `VIDEO_CAMERA` and `VIDEO_CAPTURE`. It shows your media as the viewfinder, and on
  capture it writes a JPEG frame to the caller's `EXTRA_OUTPUT` (or returns a thumbnail
  bitmap + content URI when the caller did not supply one).
- ✅ **Screen-capture fallback** — `ScreenCaptureSource` creates a
  `MediaProjection` virtual display and renders the same frames into it, so apps that
  accept a screen share will show your media.

## What needs extra setup (and why)

- ⚠️ **Being selectable as a camera *device* by apps that use Camera2/CameraX
  directly** (Instagram's in-app camera, TikTok's in-app camera, most Zoom builds,
  WhatsApp video calls). These apps never send an intent — they open the camera
  themselves. Without a HAL or a hook (options 3/4) they will show the physical camera.
  **This is the honest limitation of the APK.**
- ⚠️ **Zoom / Meet / OBS on desktop**: use the screen-share fallback and share the
  phone's screen (or run the phone's screen into the desktop client). They will not
  list "Virtual Camera" as a camera device.
- ⚠️ **Android 14+ MediaProjection**: the OS requires a per-session consent dialog and a
  foreground service of type `mediaProjection` that was started *after* consent. The app
  handles the ordering (`VirtualCameraService` waits for `startForeground` before
  calling `projection.start`), but the consent dialog is unavoidable and is shown every
  time. A permanent "screen is being shared" indicator appears — that is a deliberate
  anti-abuse control, not a bug.
- ⚠️ **Android 14+ camera foreground service**: `FOREGROUND_SERVICE_TYPE_CAMERA`
  normally requires the app to be actively using a camera. This app does not open the
  physical camera, so the typed `startForeground` is wrapped in a fallback; if the
  system rejects the typed start the service falls back to a plain foreground service
  and playback still runs (the notification just is not typed).
- ⚠️ **Video read-back is CPU-bound at 720p.** `BitmapPublisher` does a
  `glReadPixels` per frame on purpose: it keeps one code path that works for every
  consumer including the projection, at the cost of a GPU→CPU copy. A production build
  would keep the pipeline on the GPU by sharing the EGL context and rendering straight
  onto the consumer surface. Roughly: 720p30 is smooth on mid-range hardware, 1080p60
  is not.
- ⚠️ **Audio** is not routed anywhere. A camera has no audio output; if you need the
  video's sound in a livestream, mix it in on the receiving side.

---

## Project layout

```
virtual-camera/
├── build.gradle.kts                 plugin versions
├── settings.gradle.kts
├── gradle.properties
├── gradle/wrapper/                  Gradle 8.7 wrapper (checked in)
├── gradlew, gradlew.bat
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml      camera intent filters, FGS, FileProvider
        ├── java/com/teamily/virtualcamera/
        │   ├── MainActivity.kt              picker + control + capability report
        │   ├── PreviewActivity.kt           live preview from FrameBus
        │   ├── CameraIntentActivity.kt      default-camera-app entry point
        │   ├── camera/
        │   │   ├── FrameBus.kt              the single frame source of truth
        │   │   ├── VirtualCameraProvider.kt Camera2-shaped camera registry
        │   │   ├── VirtualCameraDevice.kt   Camera2-shaped device + sessions
        │   │   ├── VirtualCaptureSession.kt session that binds a Surface
        │   │   ├── SurfaceFrameWriter.kt    EGL pump: FrameBus -> any Surface
        │   │   └── gl/
        │   │       ├── EglCore.kt           EGL14 display/context/surfaces
        │   │       └── TextureQuad.kt       OES + 2D textured quad, aspect-fill
        │   ├── media/
        │   │   ├── MediaEngine.kt           ExoPlayer / image -> FrameBus
        │   │   └── BitmapPublisher.kt       SurfaceTexture -> Bitmap read-back
        │   ├── projection/
        │   │   └── ScreenCaptureSource.kt   MediaProjection fallback
        │   ├── service/
        │   │   └── VirtualCameraService.kt  foreground service, owns the engine
        │   ├── data/
        │   │   ├── MediaSelection.kt
        │   │   └── MediaRepository.kt       persisted SAF grant + prefs
        │   └── util/
        │       └── MediaFiles.kt            bitmap decode / video frame / crop
        └── res/                            layouts, values, drawables, file_paths
```

### How a frame travels

```
file (SAF uri)
   ↓  MediaEngine (ExoPlayer → SurfaceTexture)
   ↓  BitmapPublisher (GL read-back → Bitmap)
FrameBus   ← the contract every consumer shares
   ├──→ SurfaceFrameWriter → SurfaceView        (in-app preview, honest passthrough)
   ├──→ VirtualCaptureSession → Surface         (Camera2-shaped consumer)
   └──→ ScreenCaptureSource → VirtualDisplay    (MediaProjection fallback)
```

---

## Build & install

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer — or just a JDK 17 + Android SDK
- JDK 17 (bundled with Android Studio)
- Android SDK Platform 34, Build-Tools 34.0.0
- A device or emulator on Android 7.0 (API 24) or newer

### From Android Studio
1. `File → Open…` and select the `virtual-camera` folder (the one with `settings.gradle.kts`).
2. Let Gradle sync. It downloads Gradle 8.7 and AGP 8.5.2 on first sync.
3. Pick a device and press **Run** ▶.

### From the command line
```bash
cd virtual-camera
echo "sdk.dir=$HOME/Android/Sdk" > local.properties     # your SDK path

./gradlew :app:assembleDebug        # build the APK
./gradlew :app:installDebug         # build + install on the connected device
adb shell am start -n com.teamily.virtualcamera/.MainActivity

# release build (add your own signing config first)
./gradlew :app:assembleRelease
```
The debug APK lands in `app/build/outputs/apk/debug/app-debug.apk`.
Note the debug build installs with the application id suffix `.debug`
(`com.teamily.virtualcamera.debug`) — that is intentional so it can sit next to a
release build.

---

## Using it

1. Launch **Virtual Camera**.
2. **Pick video** or **Pick image** — the system picker opens (Photo Picker on
   Android 13+, document picker otherwise).
3. **Open live preview** to confirm the media loops correctly. This is the exact
   output the camera path emits.
4. **Start virtual camera** — a notification appears; playback now survives app
   switching and screen lock.
5. Move to the app you want to feed.

### Making it the default camera app (the main path)

**Settings → Apps → Default apps → Camera app → Virtual Camera**

Path varies by OEM: on Samsung it is *Settings → Apps → Choose default apps → Camera
app*; on Xiaomi/Redmi it is *Settings → Apps → Manage apps → Default apps → Camera*.
Some OEM skins (notably several Xiaomi/OPPO builds) have removed the system "default
camera" selector — in that case use the per-app permission route below.

**Per-app alternative (works on every device):** open the target app's camera, and when
the system asks *"Open with"*, choose **Virtual Camera** and tap **Always**. Or set it
under *Settings → Apps → \<target app\> → Open by default*.

Once set, any `IMAGE_CAPTURE` / `STILL_IMAGE_CAMERA` / `VIDEO_CAMERA` / `VIDEO_CAPTURE`
request resolves to `CameraIntentActivity`, which shows your media and returns a frame
from it on capture.

To stop being the default camera, change the default back to the stock camera app.

### Using the screen-capture fallback

1. Pick a file and **Start virtual camera**.
2. Tap **Start screen source** and accept the screen-capture consent dialog.
3. In the receiving app choose **Share screen / Screen** rather than a camera. In Zoom
   mobile this is *Share → Screen*; on a desktop client, join from the phone or use the
   phone as a screen source.

---

## Verification checklist

This exact tree was compiled and packaged with `./gradlew :app:assembleDebug`
(AGP 8.5.2 / Gradle 8.7 / JDK 17 / compileSdk 34), producing a 9.0 MB
`app-debug.apk`. Verified from the built APK with `aapt dump`:

- `sdkVersion 24`, `targetSdkVersion 34`, launcher activity `MainActivity`
- all six camera intent actions present on `CameraIntentActivity`
- `foregroundServiceType` on the service resolves to `0x60` = `camera | mediaProjection`
- the `FileProvider` is registered with the `${applicationId}.fileprovider` authority

Compilation is clean (warnings only, no errors). What has **not** been verified is
runtime behaviour on a physical device — there is no Android hardware here. Treat the
checklist below as the acceptance test before you rely on it.

Before trusting it in a live stream:

- [ ] Preview shows the media looping with a plausible fps (≈30) and no black frames.
- [ ] After **Start virtual camera**, the notification's Stop action really stops it
      and the preview returns to "Idle".
- [ ] After a **reboot**, launching the app still shows the previously picked file —
      if it does not, the provider did not honour the persisted grant and you need to
      re-pick (the app tells you: *"Media permission lost — pick the file again"*).
- [ ] With the app set as the default camera, the stock **Camera** app icon opens
      Virtual Camera instead of the sensor.
- [ ] A test `IMAGE_CAPTURE` from another app returns a JPEG that matches your media.

---

## Extending to a real system camera (options 3 & 4)

The seams are already there. Concretely:

**HAL route** — build `camera.virtual.so` against the AOSP
`hardware/interfaces/camera/provider`, serve `ICameraProvider` /
`ICameraDevice` over `/dev/socket`, and have the HAL read frames from a local
socket that a small privileged companion fills from `FrameBus`. Add
`camera.virtual` to the camera provider allow-list in
`/vendor/etc/camera/camera_config.xml` and push the `.so` to
`/vendor/lib64/hw/`. The device will then appear in `CameraManager.getCameraIdList()`
for *every* app. Requires a rooted device or a custom ROM build — this is
vendor-signed code, not something an APK can install.

**LSPosed route** — hook `CameraManager.openCamera` and
`CameraDeviceImpl.createCaptureSession` in the target process and redirect to
`VirtualCameraProvider.openCamera` / `VirtualCameraDevice.createCaptureSession`, with
frames crossing processes over a socket or `ashmem`. `VirtualCameraProvider` and
`VirtualCameraDevice` were written with matching signatures (camera ids, characteristics,
`DeviceStateCallback`, `CaptureRequest`, `CaptureSessionCallback`) so the hook stays
small. Requires root + LSPosed.

Both routes are deliberately **not** shipped here: they cannot be distributed as a
Play-Store-installable APK, and pretending otherwise would be the dishonest version of
this project.

---

## Legal & platform notes

- Recording or streaming someone else's video as your own camera feed can violate the
  terms of service of the platform you are streaming to (YouTube, TikTok, Instagram,
  Zoom) and, depending on jurisdiction and content, copyright or impersonation law.
  Use it for legitimate purposes: virtual backgrounds, pre-recorded segments you own,
  testing, accessibility, demos, privacy masking.
- Android's screen-capture indicator and camera-in-use indicator are mandatory and
  cannot be suppressed by a normal app. Do not expect this app to hide them.
- `MediaProjection` consent is per-session by design on Android 14+.
