package com.teamily.virtualcamera.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.teamily.virtualcamera.MainActivity
import com.teamily.virtualcamera.R
import com.teamily.virtualcamera.camera.FrameBus
import com.teamily.virtualcamera.camera.VirtualCameraDevice
import com.teamily.virtualcamera.camera.VirtualCameraProvider
import com.teamily.virtualcamera.data.MediaRepository
import com.teamily.virtualcamera.data.MediaSelection
import com.teamily.virtualcamera.media.MediaEngine
import com.teamily.virtualcamera.projection.ScreenCaptureSource

/**
 * Keeps the virtual camera alive in the background.
 *
 * Responsibilities:
 *  1. Run [MediaEngine] so frames keep being decoded into [FrameBus] while the
 *     user is in another app (Zoom, TikTok, YouTube…).
 *  2. Host the Camera2-shaped [VirtualCameraDevice] and expose it to in-process
 *     consumers (the intent-filter activity, a privileged bridge, an encoder).
 *  3. Own the [ScreenCaptureSource] fallback, because on Android 14+ a
 *     MediaProjection must be started from a running foreground service.
 *
 * Declared with `foregroundServiceType="camera|mediaProjection"` — both types are
 * needed depending on which path the user turned on.
 */
class VirtualCameraService : Service() {

    companion object {
        private const val TAG = "VirtualCameraService"
        private const val CHANNEL_ID = "virtual_camera_running"
        private const val NOTIFICATION_ID = 4242

        const val ACTION_START = "com.teamily.virtualcamera.START"
        const val ACTION_STOP = "com.teamily.virtualcamera.STOP"
        const val ACTION_START_PROJECTION = "com.teamily.virtualcamera.START_PROJECTION"
        const val ACTION_STOP_PROJECTION = "com.teamily.virtualcamera.STOP_PROJECTION"

        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_FPS = "fps"

        /** True while [VirtualCameraService] is alive and publishing frames. */
        @Volatile
        var isRunning: Boolean = false
            private set
    }

    inner class LocalBinder : Binder() {
        fun service(): VirtualCameraService = this@VirtualCameraService
    }

    private val binder = LocalBinder()

    private var engine: MediaEngine? = null
    private var projection: ScreenCaptureSource? = null

    /** Handle to the Camera2-shaped device this service exposes to callers. */
    var virtualDevice: VirtualCameraDevice? = null
        private set

    var statusText: String = "Idle"
        private set

    /** Listeners for UI updates; cleared on stop. */
    private val statusListeners = mutableSetOf<(String) -> Unit>()

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createChannel()
        engine = MediaEngine(applicationContext).also { eng ->
            eng.onStateChanged = { state, message ->
                statusText = when (state) {
                    MediaEngine.State.PLAYING -> message ?: "Virtual camera running"
                    MediaEngine.State.PREPARING -> "Preparing media…"
                    MediaEngine.State.ERROR -> message ?: "Error"
                    MediaEngine.State.IDLE -> "Idle"
                }
                publishStatus()
                updateNotification()
            }
        }
        projection = ScreenCaptureSource(applicationContext).also { p ->
            p.onStatus = { msg ->
                statusText = msg
                publishStatus()
                updateNotification()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdownEverything()
                return START_NOT_STICKY
            }

            ACTION_START_PROJECTION -> {
                startForegroundSafely(includeProjection = true)
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                val fps = intent.getIntExtra(EXTRA_FPS, 30)

                // On Android 14+ the projection must be started *after* the FGS is
                // up with the mediaProjection type, hence the post to the looper.
                android.os.Handler(mainLooper).post {
                    startMediaIfSelected()
                    if (resultCode != -1 && data != null) {
                        projection?.start(resultCode, data, fps)
                    } else {
                        statusText = "Screen capture permission missing"
                        publishStatus()
                    }
                    updateNotification()
                }
                return START_STICKY
            }

            ACTION_STOP_PROJECTION -> {
                projection?.stop()
                statusText = if (engine?.isRunning == true) "Virtual camera running" else "Idle"
                publishStatus()
                updateNotification()
                return START_STICKY
            }

            else -> {
                startForegroundSafely(includeProjection = false)
                startMediaIfSelected()
                openVirtualDevice()
                return START_STICKY
            }
        }
    }

    // ------------------------------------------------------------- internals

    private fun startMediaIfSelected() {
        val selection = MediaRepository.load(this)
        if (selection == null) {
            statusText = "No media selected yet"
            publishStatus()
            return
        }
        if (!MediaRepository.canRead(this, selection.uri)) {
            statusText = "Media permission lost — pick the file again"
            publishStatus()
            return
        }
        engine?.start(selection)
    }

    /** Opens the Camera2-shaped virtual device so in-process consumers can attach. */
    private fun openVirtualDevice() {
        if (virtualDevice != null) return
        VirtualCameraProvider.openCamera(
            this,
            VirtualCameraProvider.BACK_CAMERA_ID,
            object : VirtualCameraProvider.DeviceStateCallback {
                override fun onOpened(device: VirtualCameraDevice) {
                    Log.d(TAG, "Virtual camera device opened")
                    virtualDevice = device
                    publishStatus()
                }

                override fun onDisconnected(device: VirtualCameraDevice) {
                    Log.d(TAG, "Virtual camera device disconnected")
                    virtualDevice = null
                }

                override fun onError(device: VirtualCameraDevice, error: Int) {
                    Log.e(TAG, "Virtual camera error $error")
                    virtualDevice = null
                }
            }
        )
    }

    fun addStatusListener(listener: (String) -> Unit) {
        statusListeners.add(listener)
        listener(statusText)
    }

    fun removeStatusListener(listener: (String) -> Unit) {
        statusListeners.remove(listener)
    }

    private fun publishStatus() {
        statusListeners.toList().forEach { runCatching { it(statusText) } }
    }

    fun setStatus(text: String) {
        statusText = text
        publishStatus()
        updateNotification()
    }

    private fun shutdownEverything() {
        engine?.stop()
        projection?.stop()
        virtualDevice?.close()
        virtualDevice = null
        FrameBus.clear()
        statusText = "Idle"
        publishStatus()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        isRunning = false
        engine?.release()
        engine = null
        projection?.stop()
        projection = null
        virtualDevice?.close()
        virtualDevice = null
        FrameBus.clear()
        super.onDestroy()
    }

    // -------------------------------------------------------- notification

    private fun startForegroundSafely(includeProjection: Boolean) {
        isRunning = true
        val notification = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val types = if (includeProjection) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                }
                startForeground(NOTIFICATION_ID, notification, types)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            // Android 14 throws if the camera/projection type is used without the
            // corresponding runtime grant; fall back to a plain FGS so the service
            // at least keeps the media loop alive.
            Log.w(TAG, "Typed foreground start failed, falling back", e)
            runCatching { startForeground(NOTIFICATION_ID, notification) }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, VirtualCameraService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_camera)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(statusText)
            .setContentIntent(openApp)
            .addAction(0, getString(R.string.action_stop), stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification() {
        if (!isRunning) return
        runCatching {
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(NOTIFICATION_ID, buildNotification())
        }
    }

    // ---------------------------------------------------------- public API

    /** Starts the service and begins playing whatever media is saved. */
    fun startVirtualCamera(context: Context) {
        val intent = Intent(context, VirtualCameraService::class.java)
            .setAction(ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun currentSelection(): MediaSelection? = engine?.selection
}
