package com.teamily.virtualcamera.camera

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Mirrors `android.hardware.camera2.CameraDevice` for a *virtual* camera.
 *
 * A caller opens one of these through [VirtualCameraProvider.openCamera], attaches
 * an output [Surface] with [createCaptureSession], then pushes a repeating request.
 * From then on every frame [FrameBus] receives is drawn into that Surface at the
 * requested rate — exactly the contract a real camera gives a consumer.
 *
 * This is what a privileged backend (HAL module / LSPosed hook) binds to in order
 * to feed *other* apps. In the stock-Android path the Surface belongs to this app
 * (a SurfaceView in the preview, or the encoder input for hosting apps), and the
 * "other app" side is covered by the camera intent filters — see README.
 */
class VirtualCameraDevice(
    private val context: Context,
    val cameraId: String
) {

    companion object {
        private const val TAG = "VirtualCameraDevice"
    }

    enum class State { CLOSED, OPENING, OPEN, CLOSING }

    /** Mirrors `CameraCaptureSession.StateCallback`. */
    interface CaptureSessionCallback {
        fun onConfigured(session: VirtualCaptureSession)
        fun onConfigureFailed(session: VirtualCaptureSession) {}
    }

    /** Mirrors `CameraCaptureSession.CaptureCallback` — no-op, kept for API parity. */
    interface CaptureCallback

    /** Mirrors `CaptureRequest`: just the output surface plus the target fps. */
    data class CaptureRequest(
        val outputSurface: Surface,
        val targetFps: Int = 30,
        val mirrorHorizontally: Boolean = false
    )

    private var stateCallback: VirtualCameraProvider.DeviceStateCallback? = null
    private val thread = HandlerThread("VirtualCamera-$cameraId").also { it.start() }
    private val handler = Handler(thread.looper)
    private val closed = AtomicBoolean(false)

    @Volatile
    var state: State = State.CLOSED
        private set

    @Volatile
    private var frameWriter: SurfaceFrameWriter? = null

    @Volatile
    private var session: VirtualCaptureSession? = null

    internal fun setStateCallback(callback: VirtualCameraProvider.DeviceStateCallback) {
        stateCallback = callback
    }

    internal fun transitionToOpen() {
        state = State.OPEN
    }

    /**
     * Creates a capture session that renders [FrameBus] frames into
     * [request.outputSurface]. The callback fires on this device's camera thread,
     * like the real API.
     */
    fun createCaptureSession(
        request: CaptureRequest,
        callback: CaptureSessionCallback
    ) {
        if (closed.get() || state == State.CLOSED) {
            Log.w(TAG, "createCaptureSession on a closed device")
            return
        }

        handler.post {
            val newSession = VirtualCaptureSession(this, request)
            session = newSession
            try {
                newSession.configure()
                callback.onConfigured(newSession)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to configure capture session", e)
                callback.onConfigureFailed(newSession)
                stateCallback?.onError(this, VirtualCameraProvider.ERROR_CAMERA_DEVICE)
            }
        }
    }

    /** Called by [VirtualCaptureSession] when it is ready to receive frames. */
    internal fun attachWriter(writer: SurfaceFrameWriter) {
        frameWriter?.stop()
        frameWriter = writer
    }

    internal fun detachWriter(writer: SurfaceFrameWriter) {
        if (frameWriter === writer) {
            frameWriter?.stop()
            frameWriter = null
        }
    }

    /** Mirrors `CameraDevice.close()`. */
    fun close() {
        VirtualCameraProvider.closeCamera(this)
        stateCallback?.onDisconnected(this)
    }

    internal fun closeInternal() {
        if (!closed.compareAndSet(false, true)) return
        state = State.CLOSING
        frameWriter?.stop()
        frameWriter = null
        session?.releaseInternal()
        session = null
        state = State.CLOSED
        thread.quitSafely()
        Log.d(TAG, "Camera $cameraId closed")
    }
}
