package com.teamily.virtualcamera.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri

/** Bitmap / frame helpers shared by the preview screen and the camera-intent path. */
object MediaFiles {

    /**
     * Decodes an image URI, downsampled so the longest edge is at most [maxDim].
     * Two passes (bounds, then sampled decode) keep memory low on large photos.
     */
    fun decodeBitmap(context: Context, uri: Uri, maxDim: Int = 1920): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        runCatching {
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        var longest = maxOf(bounds.outWidth, bounds.outHeight)
        while (longest / sample > maxDim) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return runCatching {
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            }
        }.getOrNull()
    }

    /**
     * Grabs a representative frame from a video — the first key frame at or
     * before [timeUs]. Used when another app asks us for a still photo while a
     * video is loaded, and for the picker thumbnail.
     */
    fun videoFrame(context: Context, uri: Uri, timeUs: Long = 0L): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (e: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    /** Duration in milliseconds, or 0 when unknown. */
    fun videoDurationMs(context: Context, uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            runCatching { retriever.release() }
        }
    }

    /** Scales [source] to cover [width] x [height] and centers it (letterbox-free crop). */
    fun centerCrop(source: Bitmap, width: Int, height: Int): Bitmap {
        if (width <= 0 || height <= 0) return source
        val scale = maxOf(width.toFloat() / source.width, height.toFloat() / source.height)
        val scaledW = (source.width * scale).toInt().coerceAtLeast(1)
        val scaledH = (source.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(source, scaledW, scaledH, true)
        val x = ((scaledW - width) / 2).coerceAtLeast(0)
        val y = ((scaledH - height) / 2).coerceAtLeast(0)
        val cropped = Bitmap.createBitmap(scaled, x, y, minOf(width, scaledW), minOf(height, scaledH))
        if (cropped != scaled && !scaled.isRecycled) scaled.recycle()
        return cropped
    }
}
