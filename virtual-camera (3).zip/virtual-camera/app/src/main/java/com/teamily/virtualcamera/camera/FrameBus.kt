package com.teamily.virtualcamera.camera

import android.graphics.Bitmap
import java.util.concurrent.atomic.AtomicReference

/**
 * The single source of truth for "what a camera frame looks like right now".
 *
 * Everything that needs to *emit* frames — the Camera2-style [VirtualCameraDevice],
 * the MediaProjection screen source, and the in-app preview — reads the latest
 * frame from here. A producer (the video decoder / image loader) calls [publish];
 * consumers either poll [latest] or register an [OnFrameListener].
 *
 * Frames are shared, so consumers must copy before mutating.
 */
object FrameBus {

    fun interface OnFrameListener {
        fun onFrame(frame: Bitmap)
    }

    private val current = AtomicReference<Bitmap?>(null)
    private val listeners = java.util.concurrent.CopyOnWriteArraySet<OnFrameListener>()

    /** Publishes a new frame. Takes ownership of [frame]; do not recycle it. */
    fun publish(frame: Bitmap) {
        current.getAndSet(frame)?.let {
            if (it != frame && !it.isRecycled) it.recycle()
        }
        listeners.forEach { listener ->
            runCatching { listener.onFrame(frame) }
        }
    }

    fun latest(): Bitmap? = current.get()

    fun addListener(listener: OnFrameListener) {
        listeners.add(listener)
    }

    fun removeListener(listener: OnFrameListener) {
        listeners.remove(listener)
    }

    fun clear() {
        current.getAndSet(null)?.let { if (!it.isRecycled) it.recycle() }
        listeners.clear()
    }

    /** True when a producer is actively feeding frames. */
    val isLive: Boolean get() = current.get()?.isRecycled == false
}
