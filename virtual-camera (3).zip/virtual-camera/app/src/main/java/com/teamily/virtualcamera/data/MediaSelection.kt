package com.teamily.virtualcamera.data

import android.net.Uri

/** What kind of media the user picked. */
enum class MediaKind { VIDEO, IMAGE }

/**
 * The currently selected media file.
 *
 * [uri] is a Storage Access Framework document URI with a *persisted* read grant
 * (see [MediaRepository.save]), which is what lets a foreground service keep
 * reading the file after the picker activity is gone and after a reboot.
 */
data class MediaSelection(
    val uri: Uri,
    val kind: MediaKind,
    val displayName: String
) {
    val isVideo: Boolean get() = kind == MediaKind.VIDEO
}
