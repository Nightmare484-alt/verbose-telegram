package com.teamily.virtualcamera.camera

import android.content.Context
import android.util.Log

/**
 * A Camera2-shaped registry of *virtual* cameras.
 *
 * ## Why this class exists
 * Android's real camera stack lives in `cameraserver`, a system daemon that only
 * binds HAL modules from `/vendor/lib/hw/camera.*.so`. A normal, unprivileged app
 * **cannot** register a camera with `CameraManager`: there is no public API for it,
 * and `CameraService` rejects providers whose UID is not in the HAL's allow-list.
 *
 * So the "provider" here mirrors the shape of `android.hardware.camera2.CameraManager`
 * (camera ids, characteristics, device-state callbacks, open/close) but lives
 * entirely in-process. It is the single, well-defined seam where a *privileged*
 * backend can be plugged in:
 *
 *  - **Stock Android (default):** frames go out through [VirtualCameraDevice] to a
 *    Surface this app owns. Other apps can only see them if this app *becomes* their
 *    camera UI — which is what the `IMAGE_CAPTURE` / `STILL_IMAGE_CAMERA` /
 *    `VIDEO_CAMERA` intent filters in AndroidManifest.xml do (see CameraIntentActivity).
 *  - **Rooted / custom ROM:** a small companion can point the `camera.virtual` HAL
 *    module at [FrameBus] over a local socket. [VirtualCameraProvider] then behaves
 *    exactly like the real provider, and every app — including ones that never
 *    launch our UI — sees the injected stream.
 *  - **LSPosed:** a hook on `CameraManager.openCamera` / `CameraDeviceImpl` can
 *    redirect to [openCamera] here. The API shape below is deliberately close to
 *    the real one to keep such a hook small.
 *
 * See README.md → "Why a normal app cannot be a system camera" for the full story.
 */
object VirtualCameraProvider {

    private const val TAG = "VirtualCameraProvider"

    /** The one virtual camera this build exposes. */
    const val BACK_CAMERA_ID = "0"

    /** A second id so apps that probe for front+back both find something. */
    const val FRONT_CAMERA_ID = "1"

    val cameraIdList: List<String> = listOf(BACK_CAMERA_ID, FRONT_CAMERA_ID)

    /** Mirrors `CameraCharacteristics` in spirit: the properties apps actually query. */
    data class VirtualCameraCharacteristics(
        val cameraId: String,
        val lensFacing: LensFacing,
        val sensorWidth: Int,
        val sensorHeight: Int,
        val supportedFps: IntRange
    )

    enum class LensFacing { BACK, FRONT }

    /** Mirrors `CameraDevice.StateCallback`. */
    interface DeviceStateCallback {
        fun onOpened(device: VirtualCameraDevice)
        fun onDisconnected(device: VirtualCameraDevice) {}
        fun onError(device: VirtualCameraDevice, error: Int) {}
    }

    const val ERROR_CAMERA_IN_USE = 1
    const val ERROR_MAX_CAMERAS_IN_USE = 2
    const val ERROR_CAMERA_DISABLED = 3
    const val ERROR_CAMERA_DEVICE = 4
    const val ERROR_CAMERA_SERVICE = 5

    private val openDevices = mutableMapOf<String, VirtualCameraDevice>()
    private val lock = Any()

    fun getCameraCharacteristics(cameraId: String): VirtualCameraCharacteristics {
        val facing = if (cameraId == FRONT_CAMERA_ID) LensFacing.FRONT else LensFacing.BACK
        return VirtualCameraCharacteristics(
            cameraId = cameraId,
            lensFacing = facing,
            sensorWidth = 1920,
            sensorHeight = 1080,
            supportedFps = 15..30
        )
    }

    /**
     * "Opens" a virtual camera. The callback fires on the calling thread, mirroring
     * Camera2's behaviour of delivering `onOpened` on the handler you pass in.
     *
     * Returns false when the camera is already open (single-client, like a real
     * camera) — the caller then receives `onError(ERROR_CAMERA_IN_USE)`.
     */
    fun openCamera(
        context: Context,
        cameraId: String,
        callback: DeviceStateCallback
    ): Boolean {
        synchronized(lock) {
            if (openDevices.containsKey(cameraId)) {
                Log.w(TAG, "openCamera($cameraId): already in use")
                val stale = VirtualCameraDevice(context.applicationContext, cameraId)
                callback.onError(stale, ERROR_CAMERA_IN_USE)
                return false
            }

            val device = VirtualCameraDevice(context.applicationContext, cameraId)
            device.setStateCallback(callback)
            openDevices[cameraId] = device

            // Real Camera2 opens asynchronously; so do we, but immediately.
            device.transitionToOpen()
            callback.onOpened(device)
            return true
        }
    }

    /** Mirrors `CameraManager.close`. Safe to call for an id that is not open. */
    fun closeCamera(device: VirtualCameraDevice) {
        synchronized(lock) {
            openDevices.remove(device.cameraId)
        }
        device.closeInternal()
    }

    /** Number of virtual cameras currently open — shown on the status screen. */
    val openCameraCount: Int get() = synchronized(lock) { openDevices.size }
}
