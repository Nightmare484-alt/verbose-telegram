package com.teamily.virtualcamera

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.teamily.virtualcamera.data.MediaKind
import com.teamily.virtualcamera.data.MediaRepository
import com.teamily.virtualcamera.databinding.ActivityMainBinding
import com.teamily.virtualcamera.service.VirtualCameraService
import com.teamily.virtualcamera.util.MediaFiles

/**
 * Home screen: pick media, start/stop the virtual camera, and read the honest
 * status of what is and is not possible on this device.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var boundService: VirtualCameraService? = null
    private var statusListener: ((String) -> Unit)? = null

    private val serviceConnection = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: android.content.ComponentName?, binder: android.os.IBinder?) {
            val local = (binder as? VirtualCameraService.LocalBinder)?.service() ?: return
            boundService = local
            val listener: (String) -> Unit = { status ->
                runOnUiThread { binding.statusText.text = status }
            }
            statusListener = listener
            local.addStatusListener(listener)
            runOnUiThread { binding.statusText.text = local.statusText }
        }

        override fun onServiceDisconnected(name: android.content.ComponentName?) {
            statusListener?.let { boundService?.removeStatusListener(it) }
            boundService = null
            statusListener = null
        }
    }

    // ---------------------------------------------------------------- pickers

    /** Photo Picker (Android 13+) or the backward-compatible SAF fallback. */
    private val pickVisualMedia = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) onMediaPicked(uri, MediaKind.VIDEO)
    }

    /** Explicit Storage Access Framework picker — always available, gives persistable grants. */
    private val pickFromStorage = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val kind = if (isVideoUri(uri)) MediaKind.VIDEO else MediaKind.IMAGE
            onMediaPicked(uri, kind)
        }
    }

    private val requestNotifications = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* The service works either way; without it the notification is silent. */ }

    private val requestProjection = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, VirtualCameraService::class.java).apply {
                action = VirtualCameraService.ACTION_START_PROJECTION
                putExtra(VirtualCameraService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(VirtualCameraService.EXTRA_RESULT_DATA, data)
                putExtra(VirtualCameraService.EXTRA_FPS, 30)
            }
            ContextCompat.startForegroundService(this, intent)
            Toast.makeText(this, R.string.toast_projection_started, Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, R.string.toast_projection_denied, Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUi()
        maybeAskNotificationPermission()
        refreshSelectedMedia()
        checkCameraCapability()
    }

    override fun onStart() {
        super.onStart()
        android.content.Intent(this, VirtualCameraService::class.java).also {
            bindService(it, serviceConnection, BIND_AUTO_CREATE)
        }
    }

    override fun onStop() {
        super.onStop()
        statusListener?.let { boundService?.removeStatusListener(it) }
        statusListener = null
        boundService = null
        runCatching { unbindService(serviceConnection) }
    }

    // ---------------------------------------------------------------- setup

    private fun setupUi() {
        binding.pickVideo.setOnClickListener { launchPicker(MediaKind.VIDEO) }
        binding.pickImage.setOnClickListener { launchPicker(MediaKind.IMAGE) }

        binding.startVirtualCamera.setOnClickListener {
            if (MediaRepository.load(this) == null) {
                Toast.makeText(this, R.string.toast_pick_media_first, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startService(
                Intent(this, VirtualCameraService::class.java)
                    .setAction(VirtualCameraService.ACTION_START)
            )
            Toast.makeText(this, R.string.toast_camera_started, Toast.LENGTH_SHORT).show()
        }

        binding.stopVirtualCamera.setOnClickListener {
            startService(
                Intent(this, VirtualCameraService::class.java)
                    .setAction(VirtualCameraService.ACTION_STOP)
            )
            Toast.makeText(this, R.string.toast_camera_stopped, Toast.LENGTH_SHORT).show()
        }

        binding.openPreview.setOnClickListener {
            val selection = MediaRepository.load(this)
            if (selection == null) {
                Toast.makeText(this, R.string.toast_pick_media_first, Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(this, PreviewActivity::class.java))
            }
        }

        binding.startProjection.setOnClickListener { requestScreenCapture() }
        binding.stopProjection.setOnClickListener {
            startService(
                Intent(this, VirtualCameraService::class.java)
                    .setAction(VirtualCameraService.ACTION_STOP_PROJECTION)
            )
        }

        binding.howItWorks.setOnClickListener {
            startActivity(Intent(android.content.Intent.ACTION_VIEW).apply {
                // Opens the README rendered on GitHub / or falls back to a dialog.
                setData(Uri.parse("https://developer.android.com/media/camera/camera2"))
            })
        }
    }

    private fun launchPicker(kind: MediaKind) {
        val requestedType = if (kind == MediaKind.VIDEO) "video/*" else "image/*"

        // Prefer the system Photo Picker on Android 13+ (no permission needed),
        // fall back to SAF OpenDocument which always returns a persistable grant.
        val usePhotoPicker = Build.VERSION.SDK_INT >= 33
        if (usePhotoPicker) {
            pickVisualMedia.launch(
                PickVisualMediaRequest(
                    if (kind == MediaKind.VIDEO) {
                        ActivityResultContracts.PickVisualMedia.VideoOnly
                    } else {
                        ActivityResultContracts.PickVisualMedia.ImageOnly
                    }
                )
            )
        } else {
            pickFromStorage.launch(arrayOf(requestedType))
        }
    }

    private fun onMediaPicked(uri: Uri, kindHint: MediaKind) {
        val kind = if (isVideoUri(uri)) MediaKind.VIDEO else kindHint
        val name = MediaRepository.displayName(this, uri)
        MediaRepository.save(this, uri, kind, name)
        refreshSelectedMedia()

        // Restart the engine immediately if the service is already up.
        boundService?.let {
            if (VirtualCameraService.isRunning) {
                startService(
                    Intent(this, VirtualCameraService::class.java)
                        .setAction(VirtualCameraService.ACTION_START)
                )
            }
        }
        Toast.makeText(this, getString(R.string.toast_selected, name), Toast.LENGTH_SHORT).show()
    }

    private fun refreshSelectedMedia() {
        val selection = MediaRepository.load(this)
        if (selection == null) {
            binding.selectedName.text = getString(R.string.no_media_selected)
            binding.selectedKind.text = ""
            binding.previewThumb.setImageDrawable(null)
            return
        }

        binding.selectedName.text = selection.displayName
        binding.selectedKind.text = getString(
            if (selection.isVideo) R.string.kind_video else R.string.kind_image
        )
        binding.openPreview.isEnabled = true

        // Thumbnail: video frame or decoded image, on a background thread.
        Thread {
            val bitmap = if (selection.isVideo) {
                MediaFiles.videoFrame(this, selection.uri)
            } else {
                MediaFiles.decodeBitmap(this, selection.uri, 640)
            }
            if (bitmap != null) {
                runOnUiThread { binding.previewThumb.setImageBitmap(bitmap) }
            }
        }.start()
    }

    /** Reports what this build can and cannot do on the current device. */
    private fun checkCameraCapability() {
        val hasCameraFeature = packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)
        val isDefaultCamera = isProbablyDefaultCameraApp()

        binding.capabilityText.text = buildString {
            append(getString(R.string.capability_device, Build.MANUFACTURER, Build.MODEL))
            append("\n")
            append(getString(R.string.capability_hardware, if (hasCameraFeature) "yes" else "no"))
            append("\n")
            append(
                getString(
                    R.string.capability_default_camera,
                    if (isDefaultCamera) getString(R.string.yes) else getString(R.string.not_yet)
                )
            )
            append("\n")
            append(getString(R.string.capability_projection_ready))
        }
    }

    private fun isProbablyDefaultCameraApp(): Boolean {
        val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
        val resolved = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolved?.activityInfo?.packageName == packageName
    }

    private fun maybeAskNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // ---------------------------------------------------------------- projection

    private fun requestScreenCapture() {
        if (MediaRepository.load(this) == null) {
            Toast.makeText(this, R.string.toast_pick_media_first, Toast.LENGTH_SHORT).show()
            return
        }
        val manager = getSystemService(android.media.projection.MediaProjectionManager::class.java)
        requestProjection.launch(manager.createScreenCaptureIntent())
    }

    private fun isVideoUri(uri: Uri): Boolean {
        val mime = contentResolver.getType(uri).orEmpty()
        if (mime.startsWith("video/")) return true
        if (mime.startsWith("image/")) return false
        val name = MediaRepository.displayName(this, uri).lowercase()
        return name.endsWith(".mp4") || name.endsWith(".mkv") || name.endsWith(".webm") ||
            name.endsWith(".mov") || name.endsWith(".3gp") || name.endsWith(".m4v")
    }
}
