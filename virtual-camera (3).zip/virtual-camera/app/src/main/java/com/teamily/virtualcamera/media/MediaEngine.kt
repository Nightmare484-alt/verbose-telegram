package com.teamily.virtualcamera.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.teamily.virtualcamera.camera.FrameBus
import com.teamily.virtualcamera.data.MediaSelection
import com.teamily.virtualcamera.util.MediaFiles
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Decodes the selected media into [FrameBus].
 *
 * Two producers feed the same bus:
 *  - **Video** — ExoPlayer renders into an offscreen [SurfaceTexture]; every
 *    `onFrameAvailable` we hand the texture to [FrameBus]… actually we copy it to a
 *    Bitmap via a small GL read-back so that *any* consumer (Camera2 device, the
 *    encoder, MediaProjection) can use it without sharing a GL context. Looping is
 *    on, so the "camera" never goes black.
 *  - **Image** — decoded once and re-published, with a slow re-publish tick so
 *    consumers that only react to changes still see a steady stream.
 *
 * Runs on its own thread + its own GL context, independent of the UI.
 */
class MediaEngine(private val context: Context) {

    companion object {
        private const val TAG = "MediaEngine"
        private const val FRAME_W = 1280
        private const val FRAME_H = 720
    }

    enum class State { IDLE, PREPARING, PLAYING, ERROR }

    var onStateChanged: ((State, String?) -> Unit)? = null
    var onFrame: ((Bitmap) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor { r ->
        Thread(r, "MediaEngine").apply { priority = Thread.NORM_PRIORITY + 1 }
    }

    private var player: ExoPlayer? = null
    private var surfaceTexture: SurfaceTexture? = null
    private var videoSurface: Surface? = null
    private var bitmapPublisher: BitmapPublisher? = null
    private val running = AtomicBoolean(false)
    private var current: MediaSelection? = null

    val isRunning: Boolean get() = running.get()
    val selection: MediaSelection? get() = current

    /** Starts (or restarts) playback of [selection] into [FrameBus]. */
    fun start(selection: MediaSelection) {
        stop()
        current = selection
        running.set(true)
        notify(State.PREPARING, null)

        if (selection.isVideo) startVideo(selection) else startImage(selection)
    }

    fun stop() {
        running.set(false)
        main.post {
            player?.let {
                runCatching { it.stop() }
                runCatching { it.release() }
            }
            player = null
            videoSurface?.release()
            videoSurface = null
            surfaceTexture?.release()
            surfaceTexture = null
            videoSurface = null
            bitmapPublisher?.stop()
            bitmapPublisher = null
            notify(State.IDLE, null)
        }
    }

    // ---------------------------------------------------------------- video

    private fun startVideo(selection: MediaSelection) {
        main.post {
            try {
                val tex = SurfaceTexture(0).apply {
                    setDefaultBufferSize(FRAME_W, FRAME_H)
                }
                surfaceTexture = tex
                val surface = Surface(tex)
                videoSurface = surface

                val exo = ExoPlayer.Builder(context).build().apply {
                    setMediaItem(MediaItem.fromUri(selection.uri))
                    repeatMode = Player.REPEAT_MODE_ONE   // loop forever = "live camera"
                    volume = 0f                          // a camera has no audio out
                    playWhenReady = true
                    setVideoSurface(surface)
                }
                player = exo

                exo.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        when (playbackState) {
                            Player.STATE_READY -> notify(
                                State.PLAYING,
                                "Video loop running"
                            )
                            Player.STATE_ENDED -> exo.seekTo(0)
                            else -> Unit
                        }
                    }

                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        Log.e(TAG, "Player error", error)
                        notify(State.ERROR, "Cannot play this video: ${error.errorCodeName}")
                    }
                })
                exo.prepare()

                // Pull one frame per vsync-ish tick and publish it.
                startBitmapPump(tex)
            } catch (e: Exception) {
                Log.e(TAG, "startVideo failed", e)
                notify(State.ERROR, e.message)
            }
        }
    }

    /**
     * Copies each decoded video frame into a Bitmap and publishes it.
     *
     * A real production build would keep everything on the GPU (share the EGL
     * context between ExoPlayer's SurfaceTexture and the consumer surface, or use
     * MediaCodec + `eglCreateWindowSurface` directly). The read-back keeps this
     * sample honest about *where* the frame goes and works with every consumer we
     * ship, including the MediaProjection fallback, at 720p.
     */
    private fun startBitmapPump(tex: SurfaceTexture) {
        val publisher = BitmapPublisher(
            surfaceTexture = tex,
            width = FRAME_W,
            height = FRAME_H,
            onBitmap = { bitmap ->
                if (running.get()) {
                    FrameBus.publish(bitmap)
                    onFrame?.invoke(bitmap)
                } else {
                    if (!bitmap.isRecycled) bitmap.recycle()
                }
            }
        )
        bitmapPublisher = publisher

        tex.setOnFrameAvailableListener({
            publisher.requestFrame()
        }, Handler(Looper.getMainLooper()))
    }

    // ---------------------------------------------------------------- image

    private fun startImage(selection: MediaSelection) {
        worker.execute {
            try {
                val bitmap = MediaFiles.decodeBitmap(context, selection.uri, 1920)
                if (bitmap == null) {
                    notify(State.ERROR, "Could not decode this image")
                    return@execute
                }
                val scaled = MediaFiles.centerCrop(bitmap, FRAME_W, FRAME_H)
                FrameBus.publish(scaled.copy(Bitmap.Config.ARGB_8888, false))
                onFrame?.invoke(scaled)
                notify(State.PLAYING, "Image shown as live camera")

                // Re-publish periodically: keeps encoders producing P-frames and
                // makes the stream look alive to consumers that time out on silence.
                while (running.get()) {
                    Thread.sleep(1000L)
                    if (running.get()) {
                        FrameBus.publish(scaled.copy(Bitmap.Config.ARGB_8888, false))
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "startImage failed", e)
                notify(State.ERROR, e.message)
            }
        }
    }

    private fun notify(state: State, message: String?) {
        main.post { onStateChanged?.invoke(state, message) }
    }

    fun release() {
        stop()
        worker.shutdownNow()
    }
}
