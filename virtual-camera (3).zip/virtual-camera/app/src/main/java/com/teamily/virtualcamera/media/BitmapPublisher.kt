package com.teamily.virtualcamera.media

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import com.teamily.virtualcamera.camera.gl.EglCore
import com.teamily.virtualcamera.camera.gl.TextureQuad
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Turns frames arriving on a [SurfaceTexture] into ordinary [Bitmap]s.
 *
 * Owns its own EGL context + offscreen pbuffer, so it is completely separate from
 * the consumer's GL context (which is what lets the same frames be published to a
 * Camera2 surface **and** read back for the preview / projection path).
 *
 * The decode loop is driven by [requestFrame] (called from the SurfaceTexture's
 * frame-available callback) with a hard floor on frame rate so a 60 fps source does
 * not saturate a mid-range phone at 720p.
 */
class BitmapPublisher(
    private val surfaceTexture: SurfaceTexture,
    private val width: Int,
    private val height: Int,
    private val minFrameIntervalMs: Long = 33L,
    private val onBitmap: (Bitmap) -> Unit
) {

    companion object {
        private const val TAG = "BitmapPublisher"
    }

    private val running = AtomicBoolean(true)
    private val thread = HandlerThread("BitmapPublisher").also { it.start() }
    private val handler = Handler(thread.looper)
    private val pending = AtomicBoolean(false)

    private var core: EglCore? = null
    private var eglSurface: android.opengl.EGLSurface? = null
    private var quad: TextureQuad? = null
    private var buffer: ByteBuffer? = null
    private var lastEmitMs = 0L
    private var started = false

    private val texMatrix = FloatArray(16)

    /** Called when a new decoder frame is available. Cheap; coalesces bursts. */
    fun requestFrame() {
        if (!running.get()) return
        if (pending.getAndSet(true)) return
        handler.post { render() }
    }

    private fun ensureGl() {
        if (started) return
        val c = EglCore()
        core = c
        eglSurface = c.createOffscreenSurface(width, height)
        c.makeCurrent(eglSurface!!)
        quad = TextureQuad(external = true)
        quad!!.viewportAspect = width.toFloat() / height.toFloat()
        GLES20.glViewport(0, 0, width, height)
        buffer = ByteBuffer.allocateDirect(width * height * 4).order(ByteOrder.nativeOrder())
        started = true
    }

    private fun render() {
        try {
            pending.set(false)
            if (!running.get()) return

            val now = System.currentTimeMillis()
            if (now - lastEmitMs < minFrameIntervalMs) return
            lastEmitMs = now

            ensureGl()
            val c = core ?: return
            val q = quad ?: return
            val surface = eglSurface ?: return

            surfaceTexture.updateTexImage()
            surfaceTexture.getTransformMatrix(texMatrix)

            GLES20.glClearColor(0f, 0f, 0f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            q.draw(texMatrix, width.toFloat() / height.toFloat())

            val buf = buffer ?: return
            buf.rewind()
            GLES20.glReadPixels(
                0, 0, width, height,
                GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf
            )

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            buf.rewind()
            bitmap.copyPixelsFromBuffer(buf)

            // GL origin is bottom-left; flip vertically for display.
            val matrix = android.graphics.Matrix().apply { postScale(1f, -1f) }
            val flipped = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, false)
            if (flipped != bitmap) bitmap.recycle()

            onBitmap(flipped)
        } catch (e: Exception) {
            Log.e(TAG, "render failed", e)
        }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        thread.quitSafely()
    }

    fun release() {
        stop()
        handler.post {
            quad?.release()
            quad = null
            core?.releaseSurface(eglSurface)
            eglSurface = null
            core?.release()
            core = null
        }
    }
}
